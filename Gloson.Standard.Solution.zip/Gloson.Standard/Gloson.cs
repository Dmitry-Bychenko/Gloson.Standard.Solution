﻿using System;

[assembly: CLSCompliant(true)]
namespace Gloson.Standard {
 
}
